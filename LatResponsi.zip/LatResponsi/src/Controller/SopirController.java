package Controller;

import Connection.DBConnection;
import Model.Sopir;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SopirController {

    public List<Sopir> getAllSopir() {
        List<Sopir> list = new ArrayList<>();
        String sql = "SELECT * FROM sopir ORDER BY id";
        Connection conn = DBConnection.getConnection();
        if (conn == null) return list;

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(new Sopir(
                    rs.getInt("id"),
                    rs.getString("nama"),
                    rs.getString("no_sim"),
                    rs.getString("no_hp")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error getAllSopir: " + e.getMessage());
        }
        return list;
    }

    public List<Sopir> searchSopir(String keyword) {
        List<Sopir> list = new ArrayList<>();
        String sql = "SELECT * FROM sopir WHERE nama LIKE ? OR no_sim LIKE ? ORDER BY id";
        Connection conn = DBConnection.getConnection();
        if (conn == null) return list;

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            String kw = "%" + keyword + "%";
            ps.setString(1, kw);
            ps.setString(2, kw);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Sopir(
                    rs.getInt("id"),
                    rs.getString("nama"),
                    rs.getString("no_sim"),
                    rs.getString("no_hp")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error searchSopir: " + e.getMessage());
        }
        return list;
    }

    public boolean tambahSopir(Sopir s) {
        String sql = "INSERT INTO sopir (nama, no_sim, no_hp) VALUES (?, ?, ?)";
        Connection conn = DBConnection.getConnection();
        if (conn == null) return false;

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, s.getNama());
            ps.setString(2, s.getNoSim());
            ps.setString(3, s.getNoHp());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error tambahSopir: " + e.getMessage());
            return false;
        }
    }

    public boolean editSopir(Sopir s) {
        String sql = "UPDATE sopir SET nama=?, no_sim=?, no_hp=? WHERE id=?";
        Connection conn = DBConnection.getConnection();
        if (conn == null) return false;

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, s.getNama());
            ps.setString(2, s.getNoSim());
            ps.setString(3, s.getNoHp());
            ps.setInt(4, s.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error editSopir: " + e.getMessage());
            return false;
        }
    }

    public boolean hapusSopir(int id) {
        String sql = "DELETE FROM sopir WHERE id=?";
        Connection conn = DBConnection.getConnection();
        if (conn == null) return false;

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error hapusSopir: " + e.getMessage());
            return false;
        }
    }
}