package Controller;

import Connection.DBConnection;
import Model.Kendaraan;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class KendaraanController {

    public List<Kendaraan> getAllKendaraan() {
        List<Kendaraan> list = new ArrayList<>();
        String sql = "SELECT * FROM kendaraan ORDER BY id";
        Connection conn = DBConnection.getConnection();
        if (conn == null) return list;

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(new Kendaraan(
                    rs.getInt("id"),
                    rs.getString("plat_nomor"),
                    rs.getString("jenis"),
                    rs.getString("merk")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error getAllKendaraan: " + e.getMessage());
        }
        return list;
    }

    public List<Kendaraan> searchKendaraan(String keyword) {
        List<Kendaraan> list = new ArrayList<>();
        String sql = "SELECT * FROM kendaraan WHERE plat_nomor LIKE ? OR merk LIKE ? ORDER BY id";
        Connection conn = DBConnection.getConnection();
        if (conn == null) return list;

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            String kw = "%" + keyword + "%";
            ps.setString(1, kw);
            ps.setString(2, kw);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Kendaraan(
                    rs.getInt("id"),
                    rs.getString("plat_nomor"),
                    rs.getString("jenis"),
                    rs.getString("merk")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error searchKendaraan: " + e.getMessage());
        }
        return list;
    }

    public boolean tambahKendaraan(Kendaraan k) {
        String sql = "INSERT INTO kendaraan (plat_nomor, jenis, merk) VALUES (?, ?, ?)";
        Connection conn = DBConnection.getConnection();
        if (conn == null) return false;

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, k.getPlatNomor());
            ps.setString(2, k.getJenis());
            ps.setString(3, k.getMerk());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error tambahKendaraan: " + e.getMessage());
            return false;
        }
    }

    public boolean editKendaraan(Kendaraan k) {
        String sql = "UPDATE kendaraan SET plat_nomor=?, jenis=?, merk=? WHERE id=?";
        Connection conn = DBConnection.getConnection();
        if (conn == null) return false;

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, k.getPlatNomor());
            ps.setString(2, k.getJenis());
            ps.setString(3, k.getMerk());
            ps.setInt(4, k.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error editKendaraan: " + e.getMessage());
            return false;
        }
    }

    public boolean hapusKendaraan(int id) {
        String sql = "DELETE FROM kendaraan WHERE id=?";
        Connection conn = DBConnection.getConnection();
        if (conn == null) return false;

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error hapusKendaraan: " + e.getMessage());
            return false;
        }
    }
}