package Model;

public class Sopir {
    private int id;
    private String nama;
    private String noSim;
    private String noHp;


    public Sopir(int id, String nama, String noSim, String noHp) {
        this.id = id;
        this.nama = nama;
        this.noSim = noSim;
        this.noHp = noHp;
    }

    public Sopir(String nama, String noSim, String noHp) {
        this.nama = nama;
        this.noSim = noSim;
        this.noHp = noHp;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNama() { return nama; }
    public void setNama(String nama) { this.nama = nama; }

    public String getNoSim() { return noSim; }
    public void setNoSim(String noSim) { this.noSim = noSim; }

    public String getNoHp() { return noHp; }
    public void setNoHp(String noHp) { this.noHp = noHp; }

    @Override
    public String toString() {
        return "Sopir{id=" + id + ", nama='" + nama + "', noSim='" + noSim + "', noHp='" + noHp + "'}";
    }
}