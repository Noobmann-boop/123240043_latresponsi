/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package View;
import Model.User;
import Model.Kendaraan;
import Controller.KendaraanController;


/**
 *
 * @author adili
 */
public class KendaraanView extends javax.swing.JFrame {
    
    private User currentUser;
    private KendaraanController Controller = new KendaraanController();
    private javax.swing.table.DefaultTableModel tableModel;
    /**
     * Creates new form KendaraanView
     * @param user
     */
    public KendaraanView(User user) {
        initComponents();
        this.currentUser = user;
        setLocationRelativeTo(null);
        setupTable();
        loadData();
    }
    
    private void setupTable() {
        tableModel = new javax.swing.table.DefaultTableModel(
            new String[]{"ID", "Plat Nomor", "Jenis", "Merk"}, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tableKendaraan.setModel(tableModel);
        tableKendaraan.getColumnModel().getColumn(0).setMaxWidth(50);
    }

    private void loadData() {
        tableModel.setRowCount(0);
        for (Kendaraan k : Controller.getAllKendaraan()) {
            tableModel.addRow(new Object[]{k.getId(), k.getPlatNomor(), k.getJenis(), k.getMerk()});
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtSearch = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        btnTambah = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnHapus = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableKendaraan = new javax.swing.JTable();

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "Plat Nomor", "Jenis", "Merk"
            }
        ));
        jScrollPane2.setViewportView(jTable2);
        if (jTable2.getColumnModel().getColumnCount() > 0) {
            jTable2.getColumnModel().getColumn(0).setHeaderValue("ID");
            jTable2.getColumnModel().getColumn(1).setHeaderValue("Plat Nomor");
            jTable2.getColumnModel().getColumn(2).setHeaderValue("Jenis");
            jTable2.getColumnModel().getColumn(3).setHeaderValue("Merk");
        }

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("DATA KENDARAAN");

        jLabel2.setText("Cari : ");

        btnSearch.setText("Cari");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        btnTambah.setText("Tambah");
        btnTambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTambahActionPerformed(evt);
            }
        });

        btnEdit.setText("Edit");
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });

        btnHapus.setText("Hapus");
        btnHapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHapusActionPerformed(evt);
            }
        });

        btnBack.setText("Kembali Ke Menu");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        tableKendaraan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tableKendaraan);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(165, 165, 165)
                .addComponent(btnTambah)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnEdit)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnHapus)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnBack)
                .addContainerGap(149, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(32, 32, 32))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 446, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnTambah)
                    .addComponent(btnEdit)
                    .addComponent(btnHapus)
                    .addComponent(btnBack))
                .addContainerGap(10, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        String kw = txtSearch.getText().trim();
        tableModel.setRowCount(0);
        java.util.List<Kendaraan> list = kw.isEmpty()
            ? Controller.getAllKendaraan()
            : Controller.searchKendaraan(kw);
        for (Kendaraan k : list)
            tableModel.addRow(new Object[]{k.getId(), k.getPlatNomor(), k.getJenis(), k.getMerk()});
    }//GEN-LAST:event_btnSearchActionPerformed

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed
        int row = tableKendaraan.getSelectedRow();
        if (row < 0) {
            javax.swing.JOptionPane.showMessageDialog(this, "Pilih data dulu!");
            return;
        }
        Kendaraan k = new Kendaraan(
            (int)tableModel.getValueAt(row,0),
            (String)tableModel.getValueAt(row,1),
            (String)tableModel.getValueAt(row,2),
            (String)tableModel.getValueAt(row,3)
        );
        showDialog(k);
    }//GEN-LAST:event_btnEditActionPerformed

    private void btnTambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTambahActionPerformed
        showDialog(null);
    }//GEN-LAST:event_btnTambahActionPerformed

    private void btnHapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHapusActionPerformed
        int row = tableKendaraan.getSelectedRow();
        if (row < 0) { javax.swing.JOptionPane.showMessageDialog(this, "Pilih data dulu!"); return; }
        int id = (int)tableModel.getValueAt(row, 0);
        if (javax.swing.JOptionPane.showConfirmDialog(this, "Yakin hapus?", "Hapus",
                javax.swing.JOptionPane.YES_NO_OPTION) == javax.swing.JOptionPane.YES_OPTION) {
            if (Controller.hapusKendaraan(id)) loadData();
            else javax.swing.JOptionPane.showMessageDialog(this, "Gagal hapus!");
        }
    }//GEN-LAST:event_btnHapusActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        dispose();
        new MenuView(currentUser).setVisible(true);
    }//GEN-LAST:event_btnBackActionPerformed

    private void showDialog(Kendaraan existing) {
        // Buat dialog sederhana pakai JOptionPane + panel
        javax.swing.JTextField fPlat = new javax.swing.JTextField(existing != null ? existing.getPlatNomor() : "");
        javax.swing.JTextField fMerk = new javax.swing.JTextField(existing != null ? existing.getMerk() : "");
        String[] jenisList = {"Truk", "Pickup", "Van"};
        javax.swing.JComboBox<String> fJenis = new javax.swing.JComboBox<>(jenisList);
        if (existing != null) fJenis.setSelectedItem(existing.getJenis());

        javax.swing.JPanel panel = new javax.swing.JPanel(new java.awt.GridLayout(6,1,5,5));
        panel.add(new javax.swing.JLabel("Plat Nomor:")); panel.add(fPlat);
        panel.add(new javax.swing.JLabel("Jenis:")); panel.add(fJenis);
        panel.add(new javax.swing.JLabel("Merk:")); panel.add(fMerk);

        int result = javax.swing.JOptionPane.showConfirmDialog(this, panel,
            existing == null ? "Tambah Kendaraan" : "Edit Kendaraan",
            javax.swing.JOptionPane.OK_CANCEL_OPTION);
        if (result == javax.swing.JOptionPane.OK_OPTION) {
            String plat = fPlat.getText().trim();
            String merk = fMerk.getText().trim();
            String jenis = (String) fJenis.getSelectedItem();
            if (plat.isEmpty() || merk.isEmpty()) {
                javax.swing.JOptionPane.showMessageDialog(this, "Field tidak boleh kosong!");
                return;
            }
            boolean ok = existing == null
                ? Controller.tambahKendaraan(new Kendaraan(plat, jenis, merk))
                : Controller.editKendaraan(new Kendaraan(existing.getId(), plat, jenis, merk));
            if (ok) loadData();
            else javax.swing.JOptionPane.showMessageDialog(this, "Gagal simpan!");
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnHapus;
    private javax.swing.JButton btnSearch;
    private javax.swing.JButton btnTambah;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable tableKendaraan;
    private javax.swing.JTextField txtSearch;
    // End of variables declaration//GEN-END:variables
}
